const mongoose = require('mongoose')

mongoose.connect('mongodb+srv://maheeenproj1:yz2yng4c123@cluster0-hsp0u.mongodb.net/olx-db',
	{
		useNewUrlParser: true,
		 useUnifiedTopology: true
	})
